export enum ActionType {
    getUser,
    updateIsLogin,
    getAllVacations,
    getFollowedVacations,
    addNewVacation,
    deleteVacation,
    updateVacation
}