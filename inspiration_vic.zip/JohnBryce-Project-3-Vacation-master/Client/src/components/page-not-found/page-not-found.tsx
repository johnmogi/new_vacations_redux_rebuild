import React from 'react';

export const PageNotFound = () => {
    return <h1 style={{fontSize: '60px'}}>Page not found !</h1>
}