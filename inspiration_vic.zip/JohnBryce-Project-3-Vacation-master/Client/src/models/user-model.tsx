export class UserModel {
    public constructor(public userID?:number ,public firstName?:string ,public lastName?:string ,
        public userName?:string ,public password?:string , public isAdmin?:number){}
}